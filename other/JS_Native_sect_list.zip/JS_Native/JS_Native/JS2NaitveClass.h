//
//  JS2NaitveClass.h
//  JS_Native
//
//  Created by 李扬 on 2019/4/18.
//  Copyright © 2019 李扬. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef Js2NativeSectName
#define Js2NativeSectName "Js2NativeSect"
#endif

#define Js2NativeDATA(sectname) __attribute((used, section("__DATA, "#sectname" ")))

#define JS2NATIVE_SECT_EXPORT_METHOD(JsName) \
char * k##JsName##_Js2Native_service Js2NativeDATA(Js2NativeSect) = "{ \""#JsName"\" : \"""js2native_"#JsName"""\"}";\
- (void)Js2Native__##JsName

#define JS2NATIVE_SECT_EXPORT_METHOD_PARAMS(JsName, ...) \
char * k##JsName##_Js2Native_service Js2NativeDATA(Js2NativeSect) = "{ \""#JsName"\" : \"""js2native_"#JsName"""\"}";\
- (void)Js2Native__##JsName##__##__VA_ARGS__

#define JS2NATIVE_EXPORT_METHOD(JsName) \
- (void)Js2Native__##JsName

#define JS2NATIVE_EXPORT_METHOD_PARAMS(JsName, ...) \
- (void)Js2Native__##JsName##__##__VA_ARGS__

#define JS2NATIVE_ADD_METHOD(j, q) \
[JS2NaitveClass callByJsName:j query:q relation:self];

@interface JS2NaitveClass : NSObject

+ (void)sect_registerJsName:(NSString *)jsName selectorStr:(NSString *)selectorStr;

+ (void)sect_callByJsName:(NSString *)jsName query:(NSString *)query relation:(NSObject *)relation;

+ (void)callByJsName:(NSString *)jsName query:(NSString *)query relation:(NSObject *)relation;

@end



