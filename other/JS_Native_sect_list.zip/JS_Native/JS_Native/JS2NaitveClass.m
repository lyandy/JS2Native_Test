//
//  JS2NaitveClass.m
//  JS_Native
//
//  Created by 李扬 on 2019/4/18.
//  Copyright © 2019 李扬. All rights reserved.
//

#import "JS2NaitveClass.h"

#include <mach-o/getsect.h>
#include <mach-o/loader.h>
#include <mach-o/dyld.h>
#include <dlfcn.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <mach-o/ldsyms.h>

NSArray<NSString *>* Js2NativeReadConfiguration(char *sectionName,const struct mach_header *mhp);
static void js2native_dyld_callback(const struct mach_header *mhp, intptr_t vmaddr_slide)
{
    //注册 Js2Native
    NSArray<NSString *> *services = Js2NativeReadConfiguration(Js2NativeSectName, mhp);
    for (NSString *map in services)
    {
        NSData *jsonData =  [map dataUsingEncoding:NSUTF8StringEncoding];
        NSError *error = nil;
        id json = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
        
        NSCAssert(error == nil, @"js2native_dyld_callback: invalid json serialization data");
        
        if (error == nil)
        {
            NSCAssert([json isKindOfClass:[NSDictionary class]] && [json allKeys].count, @"js2native_dyld_callback: json is not kind of NSDictionary or json dict is empty");
            
            if ([json isKindOfClass:[NSDictionary class]] && [json allKeys].count)
            {
                NSString *jsName = [json allKeys][0];
                NSString *selectorStr  = [json allValues][0];
                
                NSCAssert(jsName && selectorStr, @"js2native_dyld_callback: jsName or selectorStr is nil");
                
                [JS2NaitveClass sect_registerJsName:jsName selectorStr:selectorStr];
            }
        }
    }
    
}

//注册main之前的构造函数
__attribute__((constructor))
void initProphet()
{
    //动态链接库加载的时候的hook, 可能会调用多次
    _dyld_register_func_for_add_image(js2native_dyld_callback);
}

NSArray<NSString *>* Js2NativeReadConfiguration(char *sectionName,const struct mach_header *mhp)
{
    NSMutableArray *configs = [NSMutableArray array];
    unsigned long size = 0;
#ifndef __LP64__
    uintptr_t *memory = (uintptr_t*)getsectiondata(mhp, SEG_DATA, sectionName, &size);
#else
    const struct mach_header_64 *mhp64 = (const struct mach_header_64 *)mhp;
    uintptr_t *memory = (uintptr_t*)getsectiondata(mhp64, SEG_DATA, sectionName, &size);
#endif
    
    unsigned long counter = size/sizeof(void*);
    for(int idx = 0; idx < counter; ++idx)
    {
        char *string = (char*)memory[idx];
        NSString *str = [NSString stringWithUTF8String:string];
        if(str == nil)
        {
            continue;
        }
        
        NSLog(@"config = %@", str);
        if(str != nil)
        {
            [configs addObject:str];
        }
    }
    
    return configs;
}

@interface NSObject (Andy)

- (instancetype)andy_performSelector:(SEL)selector withObjects:(NSArray *)objects;
+ (NSMutableDictionary *)andy_dictionaryWithQuery:(NSString *)query decode:(BOOL)decode;

@end

@implementation NSObject (Andy)

- (instancetype)andy_performSelector:(SEL)selector withObjects:(NSArray *)objects
{
    // 方法签名(方法的描述)
    NSMethodSignature *signature = [[self class] instanceMethodSignatureForSelector:selector];
    if (signature == nil)
    {
        //        @throw [NSException exceptionWithName:@"牛逼的错误" reason:@"方法找不到" userInfo:nil];
        [NSException raise:@"方法调用错误 " format:@" %@ 方法找不到", NSStringFromSelector(selector)];
    }
    
    // NSInvocation : 利用一个NSInvocation对象包装一次方法调用（方法调用者、方法名、方法参数、方法返回值）
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    invocation.target = self;
    invocation.selector = selector;
    
    // 设置参数
    NSInteger paramsCount = signature.numberOfArguments - 2; // 除self、_cmd以外的参数个数
    paramsCount = MIN(paramsCount, objects.count);
    for (NSInteger i = 0; i < paramsCount; i++)
    {
        id object = objects[i];
        if ([object isKindOfClass:[NSNull class]])
        {
            continue;
        }
        [invocation setArgument:&object atIndex:i + 2];
    }
    
    // 调用方法
    [invocation invoke];
    
    // 获取返回值
    id returnValue = nil;
    if (signature.methodReturnLength != 0)
    { // 有返回值类型，才去获得返回值
        [invocation getReturnValue:&returnValue];
    }
    
    return returnValue;
}

+ (NSMutableDictionary *)andy_dictionaryWithQuery:(NSString *)query decode:(BOOL)decode
{
    NSMutableDictionary *parameterDict = [NSMutableDictionary dictionary];
    for (NSString *parameters in [query componentsSeparatedByString:@"&"])
    {
        NSArray *parameterArray = [parameters componentsSeparatedByString:@"="];
        if (parameterArray.count > 1)
        {
            if (decode)
            {
                [parameterDict setObject:([parameterArray[1] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding])forKey:([parameterArray[0] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding])];
            }
            else
            {
                [parameterDict setObject:parameterArray[1] forKey:parameterArray[0]];
            }
        }
    }
    
    return parameterDict;
}

@end

@implementation JS2NaitveClass

static NSMutableDictionary<NSString *, NSString *> *__js2NativeDictM = nil;

+ (void)sect_registerJsName:(NSString *)jsName selectorStr:(NSString *)selectorStr
{
    @synchronized(self) {
        if (__js2NativeDictM == nil)
        {
            __js2NativeDictM = [NSMutableDictionary dictionary];
        }
        
        if (jsName.length > 0 && selectorStr.length > 0)
        {
            __js2NativeDictM[jsName] = selectorStr;
        }
    }
}

+ (void)sect_callByJsName:(NSString *)jsName query:(NSString *)query relation:(NSObject *)relation
{
    @synchronized(self) {
        SEL selector = nil;
        NSString *selectorStr = __js2NativeDictM[jsName];
        if (selectorStr.length > 0)
        {
            selector = NSSelectorFromString(selectorStr);
        }
        if (selector != nil)
        {
            if (query != nil)
            {
                [relation andy_performSelector:selector withObjects:@[query]];
            }
            else
            {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
                [relation performSelector:selector];
#pragma clang diagnostic pop
            }
        }
    }
}

+ (void)callByJsName:(NSString *)jsName query:(NSString *)query relation:(NSObject *)relation
{
    NSString *selStr = [self getSelByJsName:jsName relation:relation];
    
    if (selStr.length > 0 && query.length > 0)
    {
        NSArray<NSString *> *arr = [selStr componentsSeparatedByString:@"__"];
        if (arr.count == 3)
        {
            NSArray<NSString *> *paramsArr = [arr.lastObject componentsSeparatedByString:@":"];
            NSMutableArray *arrM = [NSMutableArray array];
            NSDictionary *parameters = [NSMutableDictionary andy_dictionaryWithQuery:query decode:YES];
            for (NSString *paramKey in paramsArr) {
                NSString *paramValue = parameters[paramKey];
                if (paramValue != nil)
                {
                    [arrM addObject:paramValue];
                }
            }
            
            [relation andy_performSelector:NSSelectorFromString(selStr) withObjects:[arrM copy]];
        }
    }
    else
    {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        [relation performSelector:NSSelectorFromString(selStr)];
#pragma clang diagnostic pop
    }
}

+ (NSString *)getSelByJsName:(NSString *)jsName relation:(NSObject *)relation
{
    static NSMutableDictionary *dictM = nil;
    if (dictM == nil)
    {
        dictM = [NSMutableDictionary dictionary];
        
        unsigned int count;
        Method *methods = class_copyMethodList([relation class], &count);
        for (int i = 0; i < count; i++) {
            NSString *selName = [NSString stringWithUTF8String:sel_getName(method_getName(methods[i]))];
            NSLog(@"%@", selName);
            
            if ([selName.lowercaseString hasPrefix:@"js2native_"] == YES)
            {
                NSString *jsNameKey = nil;
                
                NSArray<NSString *> *arr = [selName componentsSeparatedByString:@"__"];
                if (arr.count == 2)
                {
                    jsNameKey = arr.lastObject;
                }
                else if (arr.count == 3)
                {
                    jsNameKey = arr[1];
                }
                
                if (jsNameKey.length > 0)
                {
                    [dictM setValue:selName forKey:jsNameKey];
                }
            }
            
        }
        free(methods);
    }
    
    NSString *selStr = nil;
    
    @synchronized (self) {
        selStr = dictM[jsName];
    }
    
    return selStr;
}


@end
