//
//  ViewController+Test.m
//  JS_Native
//
//  Created by 李扬 on 2019/4/18.
//  Copyright © 2019 李扬. All rights reserved.
//

#import "ViewController+Test.h"
#import "JS2NaitveClass.h"

@implementation ViewController (Test)

JS2NATIVE_EXPORT_METHOD_PARAMS(iap_maiicon_pay, hit:(NSString *)hit callback:(NSString *)callback)
{
    self.view.backgroundColor = [UIColor redColor];
}

JS2NATIVE_EXPORT_METHOD(test_no_params)
{
    self.view.backgroundColor = [UIColor blueColor];
}

@end
